=== WP Barrister People CPT ===
Contributors: WPDevShed.com
Tags: custom post type, theme
Requires at least: 3.2
Tested up to: 3.7
Stable tag: 1.0

== Description ==

Creates "People" custom post type.

== Installation ==

1. Upload the WP Barrister People CPT plugin folder to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==

= 1.0 =
* First release