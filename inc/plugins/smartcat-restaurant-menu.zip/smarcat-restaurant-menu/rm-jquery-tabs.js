(function($) {
$( "#tabs" ).tabs();
})(jQuery);