<?php
/**
 * @link              http://www.smartcatdesign.net
 * @since             1.0.0
 * @package           smartcat-team
 *
 * @wordpress-plugin
 * Plugin Name:       Smartcat Team
 * Plugin URI:        http://www.smartcatdesign.net
 * Description:       A custom post type that enables you to add a "Team Members" section to the homepage and the product pages
 * Version:           1.0
 * Author:            Smartcat
 * Author URI:        http://www.smartcatdesign.net
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       smartcat-team
 * Domain Path:       /languages
 */
// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

add_action('init', 'smartcat_team_register');

// "Team" Custom Post Type
function smartcat_team_register() {

// register the labels for the "Team" custom post type
    $labels_team = array(
        'name' => esc_html_x('Team', 'post type general name'),
        'singular_name' => esc_html_x('Team', 'post type singular name'),
        'add_new' => esc_html_x('Add New', 'Member'),
        'add_new_item' => esc_html__('Add New Member'),
        'edit_item' => esc_html__('Edit Member'),
        'new_item' => esc_html__('New Member Item'),
        'view_item' => esc_html__('View Members Item'),
        'search_items' => esc_html__('Search Members'),
        'not_found' => esc_html__('No Members found'),
        'not_found_in_trash' => esc_html__('No Members found in Trash'),
        'parent_item_colon' => ''
    );

    // register the arguments for the "Team" custom post type	 
    $args_team = array(
        'labels' => $labels_team,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'team'),
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail')
    );
    register_post_type('smartcat_team', $args_team);
}
