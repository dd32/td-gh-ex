/* Athenea */
$(document).ready(function() {
  var menu = $('#menuf');
  var contenedor = $('#masthead');
  var cont_offset = contenedor.offset();
  $(window).on('scroll', function() {
    if($(window).scrollTop() > cont_offset.top) {
      menu.addClass('menu-fijo');
    } else {
      menu.removeClass('menu-fijo');
    }
  });
});
jQuery(document).ready(function($) {
  $(window).scroll(function(){
  // global scroll to top button
	  if ($(this).scrollTop() > 300) {
		  $('.scrolltop').fadeIn();
	  } else {
		  $('.scrolltop').fadeOut();
	  }        
  });
  // scroll nav
  $('.scroller').click(function(){
	  var section = $($(this).data("section"));
	  var top = section.offset().top-82;
	  $("html, body").animate({ scrollTop: top }, 1800);
	  return false;
  });            
});